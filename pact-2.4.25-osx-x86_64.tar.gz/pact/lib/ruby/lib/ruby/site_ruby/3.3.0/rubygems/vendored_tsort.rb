# frozen_string_literal: true

require_relative "vendor/tsort/lib/tsort"
