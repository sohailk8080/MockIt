# frozen_string_literal: true

module OpenSSL
  VERSION = "3.2.0"
end
